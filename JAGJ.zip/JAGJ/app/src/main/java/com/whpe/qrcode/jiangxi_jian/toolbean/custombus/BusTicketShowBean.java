package com.whpe.qrcode.jiangxi_jian.toolbean.custombus;

/**
 * Created by yang on 2019/1/13.
 */

public class BusTicketShowBean {
    private String buslineandsite;
    private String frequency;
    private String date;
    private String ticketid;

    public String getBuslineandsite() {
        return buslineandsite;
    }

    public void setBuslineandsite(String buslineandsite) {
        this.buslineandsite = buslineandsite;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTicketid() {
        return ticketid;
    }

    public void setTicketid(String ticketid) {
        this.ticketid = ticketid;
    }
}
