package com.whpe.qrcode.jiangxi_jian.net.getbean;

/**
 * Created by yang on 2018/10/15.
 */

public class GetOrcodeConsumeBean {


    /**
     * amount : 200
     * cityCode : 57
     * consumeTime : 20181016004516
     * orderStatus : 01
     * routeNo : 012301000001
     * tableTradeNo : 1051755953969516550
     * terminalNo : 99988888
     */

    private int amount;
    private String cityCode;
    private String consumeTime;
    private String orderStatus;
    private String routeNo;
    private String tableTradeNo;
    private String terminalNo;

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getConsumeTime() {
        return consumeTime;
    }

    public void setConsumeTime(String consumeTime) {
        this.consumeTime = consumeTime;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getRouteNo() {
        return routeNo;
    }

    public void setRouteNo(String routeNo) {
        this.routeNo = routeNo;
    }

    public String getTableTradeNo() {
        return tableTradeNo;
    }

    public void setTableTradeNo(String tableTradeNo) {
        this.tableTradeNo = tableTradeNo;
    }

    public String getTerminalNo() {
        return terminalNo;
    }

    public void setTerminalNo(String terminalNo) {
        this.terminalNo = terminalNo;
    }
}
