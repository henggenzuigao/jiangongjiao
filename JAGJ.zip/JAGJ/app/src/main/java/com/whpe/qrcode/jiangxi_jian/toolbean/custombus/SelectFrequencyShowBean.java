package com.whpe.qrcode.jiangxi_jian.toolbean.custombus;

/**
 * Created by yang on 2019/1/14.
 */

public class SelectFrequencyShowBean {

}
