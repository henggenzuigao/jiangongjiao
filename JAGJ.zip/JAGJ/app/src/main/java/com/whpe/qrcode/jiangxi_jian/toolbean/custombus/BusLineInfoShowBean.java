package com.whpe.qrcode.jiangxi_jian.toolbean.custombus;

/**
 * Created by yang on 2019/1/13.
 */

public class BusLineInfoShowBean {
    private String busNo;
    private String startSite;
    private String pointSite;
    private String ticketPrice;

    public String getBusNo() {
        return busNo;
    }

    public void setBusNo(String busNo) {
        this.busNo = busNo;
    }

    public String getStartSite() {
        return startSite;
    }

    public void setStartSite(String startSite) {
        this.startSite = startSite;
    }

    public String getPointSite() {
        return pointSite;
    }

    public void setPointSite(String pointSite) {
        this.pointSite = pointSite;
    }

    public String getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(String ticketPrice) {
        this.ticketPrice = ticketPrice;
    }
}
