package com.whpe.qrcode.jiangxi_jian.net.getbean;

/**
 * Created by yang on 2018/10/30.
 */

public class GetCheckVersioncodeBean {

    /**
     * version : 2
     * url : http://192.168.31.205:8080/download/00000001CSZX
     */

    private int version;
    private String url;

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
