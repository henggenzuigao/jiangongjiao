package com.whpe.qrcode.jiangxi_jian.toolbean.custombus;

/**
 * Created by yang on 2019/4/24.
 */

public class PassenerInfoBean {
    private String idcard;
    private String name;
    private String sex;
    private String phone;

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}
