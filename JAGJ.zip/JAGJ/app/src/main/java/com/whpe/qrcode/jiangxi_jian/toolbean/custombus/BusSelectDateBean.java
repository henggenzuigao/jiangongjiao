package com.whpe.qrcode.jiangxi_jian.toolbean.custombus;

/**
 * Created by yang on 2019/1/14.
 */

public class BusSelectDateBean {
    private String dayNum;
    private String lineRunId;
    private String linenum;
    private String surplusTicket;
    private String saleStatus;
    private String busPrice;
    private String supportVip;
    private String vipPrice;
    private String startSite;
    private String pointSite;
    private String totalLen;
    private String choosetime;
    private String isAsc;
    private String layerNum;
    private String ticketsnum;

    public String getChoosetime() {
        return choosetime;
    }

    public void setChoosetime(String choosetime) {
        this.choosetime = choosetime;
    }

    public String getIsAsc() {
        return isAsc;
    }

    public void setIsAsc(String isAsc) {
        this.isAsc = isAsc;
    }

    public String getStartSite() {
        return startSite;
    }

    public void setStartSite(String startSite) {
        this.startSite = startSite;
    }

    public String getPointSite() {
        return pointSite;
    }

    public void setPointSite(String pointSite) {
        this.pointSite = pointSite;
    }

    public String getTotalLen() {
        return totalLen;
    }

    public void setTotalLen(String totalLen) {
        this.totalLen = totalLen;
    }

    public String getDayNum() {
        return dayNum;
    }

    public void setDayNum(String dayNum) {
        this.dayNum = dayNum;
    }

    public String getLineRunId() {
        return lineRunId;
    }

    public void setLineRunId(String lineRunId) {
        this.lineRunId = lineRunId;
    }

    public String getLayerNum() {
        return layerNum;
    }

    public void setLayerNum(String layerNum) {
        this.layerNum = layerNum;
    }

    public String getSurplusTicket() {
        return surplusTicket;
    }

    public void setSurplusTicket(String surplusTicket) {
        this.surplusTicket = surplusTicket;
    }

    public String getSaleStatus() {
        return saleStatus;
    }

    public void setSaleStatus(String saleStatus) {
        this.saleStatus = saleStatus;
    }

    public String getBusPrice() {
        return busPrice;
    }

    public void setBusPrice(String busPrice) {
        this.busPrice = busPrice;
    }

    public String getSupportVip() {
        return supportVip;
    }

    public void setSupportVip(String supportVip) {
        this.supportVip = supportVip;
    }

    public String getVipPrice() {
        return vipPrice;
    }

    public void setVipPrice(String vipPrice) {
        this.vipPrice = vipPrice;
    }

    public String getTicketsnum() {
        return ticketsnum;
    }

    public void setTicketsnum(String ticketsnum) {
        this.ticketsnum = ticketsnum;
    }

    public String getLinenum() {
        return linenum;
    }

    public void setLinenum(String linenum) {
        this.linenum = linenum;
    }
}
