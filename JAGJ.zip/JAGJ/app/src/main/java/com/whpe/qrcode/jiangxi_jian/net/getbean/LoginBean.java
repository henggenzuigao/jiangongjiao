package com.whpe.qrcode.jiangxi_jian.net.getbean;

/**
 * Created by yang on 2018/10/11.
 */

public class LoginBean {

    /**
     * uid : 5938D162BD58445287313B6632379919
     * token : EF2F7D39DD5B49B4A226A5366F9D81B8
     */

    private String uid;
    private String token;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
