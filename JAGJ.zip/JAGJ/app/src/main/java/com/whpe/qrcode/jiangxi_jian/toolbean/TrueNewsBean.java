package com.whpe.qrcode.jiangxi_jian.toolbean;

/**
 * Created by yang on 2019/1/2.
 */

public class TrueNewsBean {
    private String title;
    private String info;
    private String img;
    private String contentid;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getContentid() {
        return contentid;
    }

    public void setContentid(String contentid) {
        this.contentid = contentid;
    }
}
