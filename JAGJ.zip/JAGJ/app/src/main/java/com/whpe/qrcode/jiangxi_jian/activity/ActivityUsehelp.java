package com.whpe.qrcode.jiangxi_jian.activity;


import com.whpe.qrcode.jiangxi_jian.R;
import com.whpe.qrcode.jiangxi_jian.parent.NormalTitleActivity;

/**
 * Created by yang on 2018/10/3.
 */

public class ActivityUsehelp extends NormalTitleActivity {
    @Override
    protected void afterLayout() {
        super.afterLayout();
    }

    @Override
    protected void beforeLayout() {
        super.beforeLayout();
    }

    @Override
    protected void setActivityLayout() {
        super.setActivityLayout();
        setContentView(R.layout.activity_usehelp);
    }

    @Override
    protected void onCreateInitView() {
        super.onCreateInitView();
        setTitle(getString(R.string.usehelp_title));
    }

    @Override
    protected void onCreatebindView() {
        super.onCreatebindView();
    }
}
